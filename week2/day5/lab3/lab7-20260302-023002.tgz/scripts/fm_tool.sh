#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/common.sh"

# Arxivləşdirmə funksiyası
archive_files() {
    local dir=$1
    local timestamp=$(date '+%Y%m%d_%H%M%S')
    local archive_name="$HOME/lab7-outputs/archive-$timestamp.tgz"
    
    tar -czf "$archive_name" -C "$dir" .
    log "Archive created: $archive_name"
}

# Skripti işə salırıq (nümunə olaraq tmp qovluğunu arxivləyir)
archive_files "$HOME/lab7/tmp"
